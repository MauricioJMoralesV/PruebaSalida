package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Table;

import java.util.List;
import java.util.Optional;

public interface TableService {
    Optional<Table> findById(int id);
    Optional<List<Table>> findAll();
    Optional<Table> update(Table table);
}
