package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.model.domain.dto.QuantityCalculation;
import cl.modulo7.pruebaSalida.model.domain.dto.CalculationQuantityCapacity;

import java.util.List;
import java.util.Optional;
public interface DiscountCalculationService {

}
