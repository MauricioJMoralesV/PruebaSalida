package cl.modulo7.pruebaSalida.model.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="mesa")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Mesa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    private int capacidad;
    private String ubicacion;
   //@ManyToOne(fetch = FetchType.LAZY)
   //@JoinColumn(name="mesa_id",insertable = false, updatable = false)
    // private Usuario usuario;

}
