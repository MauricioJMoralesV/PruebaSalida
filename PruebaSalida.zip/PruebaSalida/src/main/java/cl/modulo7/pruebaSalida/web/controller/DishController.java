package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Dish;
import cl.modulo7.pruebaSalida.web.service.DishService;
import cl.modulo7.pruebaSalida.web.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/dish")
public class DishController {
    private final DishService service;
    private final UserService userService;

    public DishController(DishService service, UserService userService) {
        this.service = service;
        this.userService = userService;
    }

    @GetMapping()
    public String listDish(Model model){
        model.addAttribute("listDish",service.findAll());
        return "dishs";
    }
    @GetMapping("/edit/{id}")
    public String editDish(@PathVariable int id, Model model){
        model.addAttribute("dish",service.findById(id));
        model.addAttribute("userList",userService.findAll());
        return "formDish";
    }
    @PostMapping("/edit")
    public String saveEdit(@ModelAttribute Dish dish){
        service.update(dish);
        return "redirect:/dish";

    }
}
