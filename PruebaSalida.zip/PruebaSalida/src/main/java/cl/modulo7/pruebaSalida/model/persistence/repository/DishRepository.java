package cl.modulo7.pruebaSalida.model.persistence.repository;

import cl.modulo7.pruebaSalida.model.persistence.entity.Plato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DishRepository extends JpaRepository<Plato,Integer> {
}
