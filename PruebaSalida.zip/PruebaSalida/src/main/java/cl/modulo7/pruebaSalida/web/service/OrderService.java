package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;

import java.util.List;
import java.util.Optional;

public interface OrderService {
    Optional<List<Order>> findAll();
     Optional<Order> findById(int id);
  Optional<Order> create(Order order);
    Optional<Order> update(Order order);
    boolean delete(int id);
}
