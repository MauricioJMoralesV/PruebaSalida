package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.web.service.OrderService;
import cl.modulo7.pruebaSalida.web.service.TableService;
import cl.modulo7.pruebaSalida.web.service.RequestDetailService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/requestDetail")
public class RequestDetailController {

    private final RequestDetailService service;
    private final TableService tableService;
    private final OrderService orderService;

    public RequestDetailController(RequestDetailService service, TableService tableService, OrderService orderService) {
        this.service = service;
        this.tableService = tableService;
        this.orderService = orderService;
    }

    @GetMapping()
    public String listVisit(Model model) {
        model.addAttribute("listRequestDetail", service.findAll());
        return "requestDetails";
    }



}
