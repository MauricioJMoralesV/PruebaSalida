package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Table;
import cl.modulo7.pruebaSalida.web.service.TableService;
import cl.modulo7.pruebaSalida.web.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/table")
public class TableController {
    private final TableService service;
    private final UserService userService;

    public TableController(TableService service, UserService userService) {
        this.service = service;
        this.userService = userService;

    }

    @GetMapping()
    public String listTable(Model model){
        model.addAttribute("listTables",service.findAll());
        return "tables";
    }
    @GetMapping("/edit/{id}")
    public String editTable(@PathVariable int id, Model model){
        model.addAttribute("table",service.findById(id));
        model.addAttribute("listUser",userService.findAll());
        return "formTable";
    }
    @PostMapping("/edit")
    public String saveEdit(@ModelAttribute Table table){
       service.update(table);
        return "redirect:/table";

    }

}
