package cl.modulo7.pruebaSalida.model.domain.dto;


import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Order {
    private int id;
    private Date dateOrder;
    private LocalDate date;
    private LocalTime  hour;
    private double totalOrder;
    private int employeId;
    private int tableID;
    private Employe employe;
    private Table table;
    public Order(int id, Date dateOrder, double totalOrder){
        this.id = id;
        this.dateOrder = dateOrder;
        this.totalOrder = totalOrder;
    }
    public Order(int id, Date dateOrder, LocalDate date, LocalTime hour, double totalOrder, int employeId, int tableID){
        this.id = id;
        this.dateOrder = dateOrder;
        this.totalOrder =totalOrder;
        this.employeId = employeId;
        this.tableID = tableID;
    }
}
