package cl.modulo7.pruebaSalida.model.persistence.mapper;

import cl.modulo7.pruebaSalida.model.domain.dto.CalculationQuantityCapacity;
import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.model.domain.dto.QuantityCalculation;
import cl.modulo7.pruebaSalida.model.persistence.entity.Pedido;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {DiscountCalculationMapper.class})
public interface DiscountCalculationMapper {
        @Mappings({
                @Mapping(source="descuento1",target = "discount1"),
                @Mapping(source="descuento2",target = "discount2"),
                @Mapping(source="pedidoId",target = "order"),
                @Mapping(source="platoID",target = "dish"),

        })
        Order toOrder(Pedido pedido);
        List<Order> toOrders (List<Pedido> pedidos);
        @InheritInverseConfiguration
        Pedido toPedido (Order order);
}
