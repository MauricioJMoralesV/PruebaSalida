package cl.modulo7.pruebaSalida.model.domain.dto;
import lombok.*;
import cl.modulo7.pruebaSalida.model.persistence.entity.CalculoCantidad;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
public class QuantityCalculation {
    private double discount1;

    private RequestDetail requestDetail;

    public QuantityCalculation(double discount1) {

        this.discount1 = discount1;

    }
}
