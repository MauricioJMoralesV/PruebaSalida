package cl.modulo7.pruebaSalida.model.domain.service;
import cl.modulo7.pruebaSalida.model.domain.dto.CalculationQuantityCapacity;
import cl.modulo7.pruebaSalida.model.persistence.mapper.DiscountCalculationMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.DiscountCalculationRepository;
import cl.modulo7.pruebaSalida.web.service.DiscountCalculationService;
import org.springframework.stereotype.Service;

@Service
public class CalculationQuantityCapacityServiceImpl implements DiscountCalculationService{

    private final DiscountCalculationRepository repository;
    private  final DiscountCalculationMapper mapper;

    public CalculationQuantityCapacityServiceImpl(DiscountCalculationRepository repository, DiscountCalculationMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }
}
