package cl.modulo7.pruebaSalida.model.persistence.repository;

import cl.modulo7.pruebaSalida.model.persistence.entity.CalculoCantidad;
import cl.modulo7.pruebaSalida.model.persistence.entity.CalculoCantidadCapacidad;
import cl.modulo7.pruebaSalida.model.persistence.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiscountCalculationRepository extends JpaRepository<CalculoCantidad,Integer>{
}

