package cl.modulo7.pruebaSalida.model.domain.dto;

import cl.modulo7.pruebaSalida.model.persistence.entity.Usuario;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Employe {
    private int id;
    private String name;
    private int age;
    private Date dateIni;
    private LocalDate date;
    private LocalTime  hour;

    private Usuario user;
    public Employe(int id, String name, int age, Date dateIni){
        this.id =id;
        this.name =name;
        this.age = age;
        this.dateIni = dateIni;
    }
    public Employe(int id, String name, int age, Date dateIni, LocalDate date, LocalTime hour){
        this.name = name;
        this.id =id;
        this.name =name;
        this.age = age;
        this.dateIni = dateIni;
    }
}
