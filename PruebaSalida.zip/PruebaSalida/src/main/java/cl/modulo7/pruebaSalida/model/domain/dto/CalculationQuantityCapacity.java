package cl.modulo7.pruebaSalida.model.domain.dto;
import lombok.*;
import cl.modulo7.pruebaSalida.model.persistence.entity.CalculoCantidadCapacidad;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
public class CalculationQuantityCapacity {

    private double discount2;

    private RequestDetail requestDetail;

    public CalculationQuantityCapacity(double discount2) {

        this.discount2 = discount2;

    }
}
