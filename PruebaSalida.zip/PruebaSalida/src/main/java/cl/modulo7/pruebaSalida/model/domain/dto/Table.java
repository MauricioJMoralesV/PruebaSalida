package cl.modulo7.pruebaSalida.model.domain.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Table {
    private int id;
    private int capacity;
    private String ubi;

    private User user;
}
