package cl.modulo7.pruebaSalida.model.domain.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Table;
import cl.modulo7.pruebaSalida.model.persistence.mapper.TableMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.TableRepository;
import cl.modulo7.pruebaSalida.web.service.TableService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TableServiceImpl implements TableService {
    private final TableRepository repository;
    private final TableMapper mapper;

    public TableServiceImpl(TableRepository repository, TableMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Override
    public Optional<Table> findById(int id) {


        return repository.findById(id).map(mapper::toTable);
    }

    @Override
    public Optional<List<Table>> findAll() {

        return Optional.of(mapper.toTables(repository.findAll()));
    }

    @Override
    public Optional<Table> update(Table table) {

         return Optional.of(mapper.toTable(repository.save(mapper.toMesa(table))));

    }
    public Table create(Table table){
        return mapper.toTable(repository.save(mapper.toMesa(table)));
    }
}
