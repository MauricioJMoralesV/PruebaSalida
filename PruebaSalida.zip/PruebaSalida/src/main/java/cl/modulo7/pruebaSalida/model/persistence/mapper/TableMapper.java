package cl.modulo7.pruebaSalida.model.persistence.mapper;

import cl.modulo7.pruebaSalida.model.domain.dto.Table;
import cl.modulo7.pruebaSalida.model.persistence.entity.Mesa;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {UserMapper.class})
public interface TableMapper {
   @Mappings({
           @Mapping(source="id",target="id"),
           @Mapping(source="capacidad",target="capacity"),
           @Mapping(source="ubicacion",target="ubi")
   })
   Table toTable(Mesa mesa);
    List<Table> toTables (List<Mesa> mesas);
    @InheritInverseConfiguration
    Mesa toMesa (Table table);
}
