package cl.modulo7.pruebaSalida.model.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="calculoCantidad")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CalculoCantidad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int pedidoId;
    @Column(name = "pedido_id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int platoID;
    @Column(name = "plato_id")

    private double descuento1;
}
