package cl.modulo7.pruebaSalida.model.persistence.repository;

import cl.modulo7.pruebaSalida.model.persistence.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Pedido,Integer> {
}
