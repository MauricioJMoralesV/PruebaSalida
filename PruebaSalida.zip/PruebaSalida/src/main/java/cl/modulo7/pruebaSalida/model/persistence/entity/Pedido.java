package cl.modulo7.pruebaSalida.model.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Entity
@Table(name="pedido")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    private Date fechaPedido;
    private LocalDate fecha;
    private LocalTime  hora;
    private double total;
    private int camareroId;
    private int mesaID;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="pedido_id", insertable =false, updatable=false)
    private Camarero camarero;
    private Mesa mesa;
}
