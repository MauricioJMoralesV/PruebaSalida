package cl.modulo7.pruebaSalida.model.persistence.repository;

import cl.modulo7.pruebaSalida.model.persistence.entity.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RequestDetailRepository extends JpaRepository<DetallePedido,Integer> {
}