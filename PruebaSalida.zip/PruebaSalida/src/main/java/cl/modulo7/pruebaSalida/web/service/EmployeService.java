package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Employe;

import java.util.List;
import java.util.Optional;

public interface EmployeService {
    Optional<Employe> findById(int id);
    Optional<List<Employe>>findAll();
    Optional<Employe>update(Employe employe);
}
