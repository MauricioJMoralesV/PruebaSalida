package cl.modulo7.pruebaSalida.model.persistence.mapper;

import cl.modulo7.pruebaSalida.model.domain.dto.RequestDetail;
import cl.modulo7.pruebaSalida.model.persistence.entity.DetallePedido;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import java.util.List;

@Mapper(componentModel = "spring")

public interface RequestDetailMapper {

    @Mappings({
            @Mapping(source="pedidoId",target = "orderId"),
            @Mapping(source="platoID",target = "dishID"),
            @Mapping(source="cantidad",target = "amount"),
            @Mapping(source="subTotal",target = "subTotalOrder"),

    })
    RequestDetail toRequestDetail(DetallePedido detallePedido);
    List<RequestDetail> toRequestDetails (List<DetallePedido> requestDetails);
    @InheritInverseConfiguration
    DetallePedido toRequestDetail (RequestDetail requestDetail);


}
