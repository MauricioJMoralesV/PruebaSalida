package cl.modulo7.pruebaSalida.model.persistence.mapper;

import cl.modulo7.pruebaSalida.model.domain.dto.Employe;
import cl.modulo7.pruebaSalida.model.persistence.entity.Camarero;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {UserMapper.class})
public interface EmployeMapper {
    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "nombre", target = "name"),
            @Mapping(source = "edad", target = "age"),
            @Mapping(source = "fechaIni", target = "dateIni"),
            @Mapping(source = "fecha", target = "date"),
            @Mapping(source = "hora", target = "hour"),
            @Mapping(source = "usuario", target = "user")
    })
    Employe toEmploye(Camarero camarero);
    List<Employe> toEmployes(List<Camarero> camareros);
    @InheritInverseConfiguration
    Camarero toCamarero(Employe employe);
}
