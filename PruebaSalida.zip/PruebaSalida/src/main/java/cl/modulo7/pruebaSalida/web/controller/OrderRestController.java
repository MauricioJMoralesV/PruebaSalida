package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.web.service.OrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order")
public class OrderRestController {
    private final OrderService service;

    public OrderRestController(OrderService service) {
        this.service = service;
    }
   @GetMapping("/list")
   public ResponseEntity <List<Order>> findAll(){
        return service.findAll().map(orders ->
                new ResponseEntity<>(orders, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
   }

}
