package cl.modulo7.pruebaSalida.model.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Entity
@Table(name="camarero")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Camarero {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;
    private String nombre;
    private int edad;
    private Date fechaIni;
    private LocalDate fecha;
    private LocalTime hora;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="camarero_id",insertable = false, updatable = false)
    private Usuario usuario;

}
