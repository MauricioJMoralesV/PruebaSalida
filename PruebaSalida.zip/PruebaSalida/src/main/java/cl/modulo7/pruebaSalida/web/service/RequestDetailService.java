package cl.modulo7.pruebaSalida.web.service;

import java.util.List;
import java.util.Optional;


import cl.modulo7.pruebaSalida.model.domain.dto.RequestDetail;

public interface RequestDetailService {
    public Optional<List<RequestDetail>> findAll();
    public Optional<RequestDetail> findById(int amount);
    Optional<RequestDetail> create(RequestDetail requestDetail);
    boolean delete(int id);
}
