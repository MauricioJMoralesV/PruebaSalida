package cl.modulo7.pruebaSalida.model.persistence.mapper;


import cl.modulo7.pruebaSalida.model.domain.dto.Dish;
import cl.modulo7.pruebaSalida.model.persistence.entity.Plato;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {UserMapper.class})
public interface DishMapper {

    @Mappings({
            @Mapping(source= "id", target= "id"),
            @Mapping(source= "nombre", target= "name"),
            @Mapping(source = "descripcion", target= "description"),
            @Mapping(source = "precio", target= "price"),
            @Mapping(source = "categoria", target= "category"),

    })
    Dish toDish(Plato plato);
    List<Dish> toDishs(List<Plato> dishs);
    @InheritInverseConfiguration
    Plato toDish(Dish dish);
}
