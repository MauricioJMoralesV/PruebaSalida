package cl.modulo7.pruebaSalida.model.domain.dto;

import lombok.*;

    @NoArgsConstructor
    @AllArgsConstructor
    @Getter
    @Setter
    @ToString
    public class Dish {
        private int id;
        private String name;
        private String description;
        private double price;
        private String category;

        private User user;

        public Dish(int id, String name, String description, double price, String category) {
            this.id = id;
            this.name = name;
            this.description = description;
            this.price = price;
            this.category = category;
        }
    }

