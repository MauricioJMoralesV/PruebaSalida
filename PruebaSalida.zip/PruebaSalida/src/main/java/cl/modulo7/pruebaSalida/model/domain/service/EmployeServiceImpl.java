package cl.modulo7.pruebaSalida.model.domain.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Employe;
import cl.modulo7.pruebaSalida.model.persistence.entity.Camarero;
import cl.modulo7.pruebaSalida.model.persistence.mapper.EmployeMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.EmployeRepository;
import cl.modulo7.pruebaSalida.web.service.EmployeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class EmployeServiceImpl implements EmployeService {
    private final EmployeRepository repository;
    private final EmployeMapper mapper;

    public EmployeServiceImpl(EmployeRepository repository, EmployeMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Override
    public Optional<Employe> findById(int id) {
        return repository.findById(id).map(mapper::toEmploye);
    }

    @Override
    public Optional<List<Employe>> findAll() {
        return Optional.of(mapper.toEmployes(repository.findAll()));

    }

    @Override
    public Optional<Employe> update(Employe employe) {
        return Optional.of(mapper.toEmploye(repository.save(mapper.toCamarero(employe))));
    }
}
