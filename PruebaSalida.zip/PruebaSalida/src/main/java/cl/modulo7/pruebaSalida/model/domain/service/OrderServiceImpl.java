package cl.modulo7.pruebaSalida.model.domain.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.model.persistence.mapper.OrderMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.OrderRepository;
import cl.modulo7.pruebaSalida.web.service.OrderService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {
    private final OrderRepository repository;
    private  final OrderMapper mapper;

    public OrderServiceImpl(OrderRepository repository, OrderMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }


    @Override
    public Optional<List<Order>> findAll() {

        return Optional.of(mapper.toOrders(repository.findAll()));
    }

    @Override
    public Optional<Order> findById(int id) {
        return repository.findById(id).map(mapper::toOrder);
    }

    @Override
    public Optional<Order> create(Order order) {

        return  Optional.of(mapper.toOrder(repository.save(mapper.toPedido(order))));
    }
    @Override
    public Optional<Order> update(Order order){
        return Optional.of(mapper.toOrder(repository.save(mapper.toPedido(order))));
    }
    @Override
    public boolean delete(int id){
        if(repository.existsById(id)){
            repository.deleteById(id);
            return true;
        }return false;
    }
}
