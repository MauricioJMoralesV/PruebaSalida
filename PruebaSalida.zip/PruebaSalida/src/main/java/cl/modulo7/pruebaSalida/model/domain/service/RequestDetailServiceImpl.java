package cl.modulo7.pruebaSalida.model.domain.service;
import cl.modulo7.pruebaSalida.model.domain.dto.RequestDetail;
import cl.modulo7.pruebaSalida.model.persistence.mapper.RequestDetailMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.RequestDetailRepository;
import cl.modulo7.pruebaSalida.web.service.RequestDetailService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RequestDetailServiceImpl implements RequestDetailService {

    private final RequestDetailRepository repository;
    private final RequestDetailMapper mapper;


    public RequestDetailServiceImpl(RequestDetailRepository repository, RequestDetailMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public Optional<List<RequestDetail>> findAll() {
        return Optional.of(mapper.toRequestDetails(repository.findAll()));
    }

    @Override
    public Optional<RequestDetail> findById(int cantidad) {
        return repository.findById(cantidad).map(mapper::toRequestDetail);
    }

    @Override
    public Optional<RequestDetail> create(RequestDetail requestDetail) {
        return Optional.empty();
    }

    @Override
    public boolean delete(int id) {
        return false;
    }


}
