package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Employe;
import cl.modulo7.pruebaSalida.web.service.EmployeService;
import cl.modulo7.pruebaSalida.web.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/employe")
public class EmployeController {
    private final EmployeService service;
    private final UserService userService;

    public EmployeController(EmployeService service, UserService userService) {
        this.service = service;
        this.userService = userService;
    }
    @GetMapping()
    public String list(Model model){
        model.addAttribute("list",service.findAll());
        model.addAttribute("users",userService.findAll());
        return "employes";
    }
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable int id, Model model){
        model.addAttribute("employe",service.findById(id));
        //podría ser si usuario?
        model.addAttribute("users",userService.findAll());
        return "formEmploye";
    }
    @PostMapping("/edit")
    public String saveEdit(@ModelAttribute Employe employe){
        service.update(employe);
        return"redirect:/user/users";
    }
}
