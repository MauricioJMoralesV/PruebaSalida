package cl.modulo7.pruebaSalida.model.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="plato")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Plato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private String categoria;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "plato_id", insertable = false, updatable = false)
    private Usuario usuario;
/*    @Column(name = "usuario_id")
    private String userId;*/
}
