package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    public Optional<List<User>> findAll();
    public Optional<User> findById(int id);
    Optional<User> create(User user);
}
