package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.web.service.TableService;
import cl.modulo7.pruebaSalida.web.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/order")
public class OrderController {
    //inyección de dependencia- servicioInterface
    private final OrderService service;
    private final TableService tableService;

    public OrderController(OrderService service, TableService tableService) {
        this.service = service;
        this.tableService = tableService;

    }

    @GetMapping
    public String formOrder(Model model){
        model.addAttribute("tab", tableService.findAll());
        model.addAttribute("newOrder", new Order());
        return "formOrder";
    }
    @PostMapping
    public String createOrder(@ModelAttribute Order order){

    service.create(order);
    return "redirect:/order/list";
    }
    //Caso de uso Listar pedidos
    @GetMapping("/list")
    public String findAll(Model model){
        model.addAttribute("listOrders",service.findAll());
        return "orders";
    }

}
