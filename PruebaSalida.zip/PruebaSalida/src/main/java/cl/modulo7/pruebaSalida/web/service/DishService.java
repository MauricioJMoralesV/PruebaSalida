package cl.modulo7.pruebaSalida.web.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Dish;

import java.util.List;
import java.util.Optional;

public interface DishService {

    Optional<List<Dish>> findAll();
    Optional<Dish> findById(int id);
    Optional<Dish> create(Dish dish);
    Optional<Dish> update(Dish dish);
    boolean delete(int id);
}
