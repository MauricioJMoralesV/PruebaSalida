package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.Table;
import cl.modulo7.pruebaSalida.web.service.TableService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/table")
public class TableRestController {
    private final TableService service;

    public TableRestController(TableService service) {
        this.service = service;
    }
    @GetMapping
    public ResponseEntity <List<Table>> findAll(){
        return service.findAll().map(tables ->
                new ResponseEntity<>(tables, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}
