package cl.modulo7.pruebaSalida.web.controller;

import cl.modulo7.pruebaSalida.model.domain.dto.User;
import cl.modulo7.pruebaSalida.model.persistence.mapper.UserMapper;
import cl.modulo7.pruebaSalida.web.service.EmployeService;
import cl.modulo7.pruebaSalida.web.service.TableService;
import cl.modulo7.pruebaSalida.web.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService service;
private final TableService tableService;
private final EmployeService employeService;
private final UserMapper mapper;
    public UserController(UserService service, TableService tableService, EmployeService employeService, UserMapper mapper) {
        this.service = service;
        this.tableService = tableService;
        this.employeService = employeService;
        this.mapper = mapper;
    }

    //controlador caso uso listar usuarios
@GetMapping("users")
    public String listaUsuarios(Model model){
        model.addAttribute("listUsers", service.findAll());
        return "users";
    }
@GetMapping()
    public String formUser(){
        return "formUser";
}
    @PostMapping()
    public String createUser(@ModelAttribute User user){
        service.create(user);
        return "redirect:/user/users";
    }

}
