package cl.modulo7.pruebaSalida.web.controller;

public class MainController {
}
