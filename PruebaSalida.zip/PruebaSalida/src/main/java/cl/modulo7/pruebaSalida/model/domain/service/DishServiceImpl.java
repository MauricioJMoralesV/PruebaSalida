package cl.modulo7.pruebaSalida.model.domain.service;

import cl.modulo7.pruebaSalida.model.domain.dto.Dish;
import cl.modulo7.pruebaSalida.model.persistence.mapper.DishMapper;
import cl.modulo7.pruebaSalida.model.persistence.repository.DishRepository;
import cl.modulo7.pruebaSalida.web.service.DishService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DishServiceImpl implements DishService {

    private final DishRepository repository;
    private final DishMapper mapper;

    public DishServiceImpl(DishRepository repository, DishMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;


    }

    @Override
    public Optional<List<Dish>> findAll() {
        return Optional.of(mapper.toDishs(repository.findAll()));
    }

    @Override
    public Optional<Dish> findById(int id) {
        return repository.findById(id).map(mapper::toDish);
    }

    @Override
    public Optional<Dish> create(Dish dish) {
        return  Optional.of(mapper.toDish(repository.save(mapper.toDish(dish))));
    }

    @Override
    public Optional<Dish> update(Dish dish) {
        return Optional.of(mapper.toDish(repository.save(mapper.toDish(dish))));
    }

    @Override
    public boolean delete(int id) {
        //adaptación ya que repo.delete() es de tipo void
        if(repository.existsById(id)){
            repository.deleteById(id);
            return true;
        }return false;
    }
}
