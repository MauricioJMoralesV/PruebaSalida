package cl.modulo7.pruebaSalida.model.domain.dto;

import lombok.*;

@NoArgsConstructor
@ToString
public class RequestDetail {

    private int amount;
    private double subTotalOrder;
    private int orderId;
    private int dishID;
    private Order order;
    private Dish dish;

    public RequestDetail(int amount, double subTotalOrder, int orderId, int dishID) {
        this.amount = amount;
        this.subTotalOrder = subTotalOrder;
        this.orderId = orderId;
        this.dishID = dishID;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getSubTotalOrder () {
        return subTotalOrder;
    }
    public void setSubTotalOrder(int subTotalOrder) {
        this.subTotalOrder = subTotalOrder;
    }
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getDishID() {
        return dishID;
    }

    public void setDishID(int dishID) {
        this.dishID = dishID;
    }

}
