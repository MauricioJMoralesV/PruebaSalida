package cl.modulo7.pruebaSalida.model.persistence.mapper;

import cl.modulo7.pruebaSalida.model.domain.dto.Order;
import cl.modulo7.pruebaSalida.model.persistence.entity.Pedido;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {TableMapper.class})
public interface OrderMapper {
    @Mappings({
            @Mapping(source="id",target = "id"),
            @Mapping(source="fechaPedido",target = "dateOrder"),
            @Mapping(source="fecha",target = "date"),
            @Mapping(source="hora",target = "hour"),
            @Mapping(source="total",target = "totalOrder"),
            @Mapping(source="camarero",target = "employe"),
            @Mapping(source="mesa",target = "table"),

    })
    Order toOrder(Pedido pedido);
    List<Order> toOrders (List<Pedido> pedidos);
    @InheritInverseConfiguration
    Pedido toPedido (Order order);
}
