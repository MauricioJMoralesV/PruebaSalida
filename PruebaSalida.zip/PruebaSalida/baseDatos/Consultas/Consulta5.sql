-- Consulta 5
-- Se solicita una lista con los platos vendidos y el valor total que se ha obtenido por cada plato, agrupados por el nombre del plato y ordenados de forma ascendente.
USE Restaurant;

SELECT P.Nombre AS PlatoVendido, SUM(DP.Subtotal) AS ValorTotalObtenido
FROM Plato AS P
JOIN Detalle_Pedido AS DP ON P.ID = DP.Plato_ID
GROUP BY P.Nombre
ORDER BY PlatoVendido ASC;
