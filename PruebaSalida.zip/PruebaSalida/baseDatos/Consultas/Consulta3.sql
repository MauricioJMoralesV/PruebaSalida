-- Consulta 3
-- Se solicita una lista con el monto de ventas de cada camarero, ordenados alfabéticamente de forma descendente, agrupados por el nombre del camarero.
USE Restaurant;

SELECT C.Nombre AS NombreCamarero, SUM(DP.Subtotal) AS MontoVentas
FROM Camarero AS C
LEFT JOIN Pedido AS P ON C.ID = P.Camarero_ID
LEFT JOIN Detalle_Pedido AS DP ON P.ID = DP.Pedido_ID
GROUP BY C.ID
ORDER BY NombreCamarero DESC;