-- Consulta 1
-- Se solicita mostrar los nombres y cantidades solicitadas de los platos en el pedido de id 1.
USE Restaurant;

SELECT P.Nombre AS NombrePlato, DP.Cantaidad
FROM Pedido AS PE
JOIN Detalles_Pedido AS DP ON PE.ID = DP.Pedido_ID
JOIN Plato AS P ON DP.Plato_ID = P.ID
WHERE PE.ID = 1;