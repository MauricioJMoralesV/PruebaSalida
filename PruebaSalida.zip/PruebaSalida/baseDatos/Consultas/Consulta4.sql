-- Consulta 4
-- Se solicita mostrar el plato más solicitado y la cantidad correspondiente de solicitudes.

USE Restaurant;
SELECT P.Nombre AS PlatoMasSolicitado, SUM(DP.Cantidad) AS CantidadSolicitudes
FROM Plato AS P
JOIN Detalle_Pedido AS DP ON P.ID = DP.Plato_ID
GROUP BY P.ID
ORDER BY CantidadSolicitudes DESC
LIMIT 1;