-- Consulta 2
-- Se solicita una lista con la cantidad de pedidos que recibido cada mesa
USE Restaurant;

SELECT M.Numero AS NumeroMesa, COUNT(P.ID) AS CantidadPedidos
FROM Mesa AS M
LEFT JOIN Pedido AS P ON M.ID = P.Mesa_ID
GROUP BY M.ID;
